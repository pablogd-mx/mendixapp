//>>built
define("dijit/nls/he/common",({buttonOk:"אישור",buttonCancel:"ביטול",buttonSave:"שמירה",itemClose:"סגירה"}));
