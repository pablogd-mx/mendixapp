//>>built
define("dijit/nls/sk/common",({buttonOk:"OK",buttonCancel:"Zrušiť",buttonSave:"Uložiť",itemClose:"Zatvoriť"}));
